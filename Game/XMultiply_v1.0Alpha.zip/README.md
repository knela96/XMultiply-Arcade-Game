--X-Multiply Replica--

The game centers around an unusual alien invasion against a colony planet in the year 2249�the aliens themselves are microscopic creatures that invade, infect, and kill the colonists. Scientists have deployed the microscopic fighter X-002 into the body of the hapless woman whose body has been invaded by the alien queen.

--Installation--

Just download the latest release and extecute it, there is no secret

--Controls--

INTRO to navigate through screens

W/A/S/D to move the player

SPACE to shoot missiles

There are currently five power-ups, each of them specified inside the wiki 
(the bomb, the speed up, the tentacles, the yellow shells and the missiles)

For debuf purposes, we implemented some special keys in order to make the game easier to play;
F1 to see collision layout, F2 to win, F3 to lose, and F5 activates Godmode.

--Changelist versions-----

XMultiply v0.1===============

-Added A Tilemap
-Player Movement
-Added Player Texture

XMultiply v0.2===============

- Added Parallax Effect
- Player Animation
- Change Between Scenes
- Player Shoot Feature

XMultiply v0.3===============

- Added Sound into Scenes

XMultiply v0.35==============

- Added UI
- Added Enemy + Movement
- Added Collisions

XMultiply v0.4 ==============

- Added Fonts

XMultiply v0.5 ==============

- Added powerUps
- Created new Enemies + Attack + Path
- PowerUps: Tentacles, Bomb, Propulsion
- Implemented some UI + Score
- Bug Fixing
- Fixed Some Memory Leaks



XMultiply v0.6 ==============

-FullScreen Implemented
-GamePad Implemented


XMultiply v1.0 ==============

-Level 4 Module Implemented + Backround Movement
-3 New Enemies Implemented.
-Ghoums, the fourth level boss implemented.
-Tentacles finally corrected
-Implemented a new power-up, Yellow Shells.
-Missiles implemented
-Lives are correctly shown in UI.
-Score Scene to check score at the end implemented.

==========================================

--Authors---------

- Management
	- Rafel Brau
	- Github: https://github.com/Rafefix
- Art & Design
	- Pol Cort�s
	- Github: https://github.com/PolCorTs
- Code
	- �ric Canela
	- Github: https://github.com/knela96
- QA
	- Ferran Barn�s
	- Github: https://github.com/FBarnes99